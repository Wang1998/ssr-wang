<?php

namespace Tests\Services;

use Tests\TestCase;

class FactoryTest extends TestCase
{
    public function testAuth()
    {
    }
}
