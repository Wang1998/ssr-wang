<?php

return [
    "nodes" => '节点',
    "config" => "配置",
    "users" => '用户',
    'mail-setting' => '邮件配置',
];
