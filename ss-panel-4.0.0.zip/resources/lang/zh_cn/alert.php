<?php

return [
    'success' => '成功!',
    'error' => '出错了!',
];
