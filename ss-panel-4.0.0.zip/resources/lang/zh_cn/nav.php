<?php

return [
    'home' => '主页',
    'user-center' => '用户中心',
    'download' => '下载',
    'invite-code' => '邀请码',

    'pages' => '页面',
    'about' => '关于',
    'about-des' => "A way to share shadowsocks.",
    'user' => '用户',
    'tos' => 'TOS',
];
