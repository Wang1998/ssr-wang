<?php

return [

    'announcement' => '公告',
    'faq' => '常见问题',

    'checkin' => '签到',
    'checkin-des' => "每 %s 小时可以签到一次。",
    'cant-checkin' => "无法签到",
    'last-checkin-at' => '上次签到时间',
    'traffic-got' => '你获得了 ',

    'traffic-info' => '流量使用情况',
    'traffic-total' => '总流量',
    'traffic-used' => '已用流量',
    'traffic-unused' => '剩余流量',

    'connection-info' => '链接信息',

    'last-used' => '上次使用于',
    'gen-invite-code' => '生成邀请码',
];
