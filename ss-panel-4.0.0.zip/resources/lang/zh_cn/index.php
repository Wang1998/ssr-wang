<?php

return [
    'sign-up-now' => '立即注册',
    'info' => 'over the wall!',
    'enter-user-center' => '用户中心',
];
