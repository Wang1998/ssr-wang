<?php

return [
    'home' => 'Home',
    'user-center' => 'User Center',
    'download' => 'Download',
    'invite-code' => 'Invite Code',

    'pages' => 'Pages',
    'about' => 'About',
    'about-des' => "A way to share shadowsocks.",
    'user' => 'User',
    'tos' => 'TOS',
];
