<?php

return [
    'success' => 'Success',
    'error' => 'Whoops',
];
