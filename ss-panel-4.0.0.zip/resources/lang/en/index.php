<?php

return [
    'sign-up-now' => 'Sign Up Now',
    'info' => 'over the wall!',
    'enter-user-center' => 'User Center',
];
