## Dev Guide

### Commands

####  Generate Vue Lang js file

```
php xcat genVueLang
```

####  Run Migrations

```
php xcat migrate
```

####  Create Admin

```
php xcat createAdmin <email> <password>
```