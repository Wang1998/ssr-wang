<?php

namespace App\Console\Commands;

class Job
{
}
