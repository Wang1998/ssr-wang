<?php

return [
    'dashboard' => '控制面板',
    'user-home' => '用户中心',
    'node-list' => '节点列表',
    'my-profile' => '个人信息',
    'traffic-log' => '流量日志',
    'edit-profile' => '编辑',
    'invite-friend' => '邀请好友',
    'admin-panel' => '管理面板',

    'join-at' => '加入于',
];
