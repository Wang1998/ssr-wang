<?php

return [
    'add' => '添加',
    'delete' => '删除',
    'action' => '操作',
    'node-add' => '添加节点',

    'num' => '数量',
    'prefix' => '前缀',

    'home-message' => '首页消息公告',

    'users-total' => '总用户',
    'nodes-total' => '节点数量',
    'traffic-total' => '产生流量',
];