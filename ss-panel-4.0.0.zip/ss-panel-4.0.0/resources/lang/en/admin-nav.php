<?php

return [
    "nodes" => 'Nodes',
    "config" => "Config",
    "users" => 'Users',
    'mail-setting' => 'Mail Setting',
];
