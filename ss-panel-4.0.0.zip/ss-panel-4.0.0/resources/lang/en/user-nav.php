<?php

return [
    'dashboard' => 'Dashboard',
    'user-home' => 'User Center',
    'node-list' => 'Node List',
    'my-profile' => 'My Profile',
    'traffic-log' => 'Traffic Log',
    'edit-profile' => 'Edit Profile',
    'invite-friend' => 'Invite Friend',
    'admin-panel' => 'Admin Panel',

    'join-at' => 'Join At',
];
