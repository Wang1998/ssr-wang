<?php

return [
    'add' => 'Add',
    'delete' => 'Delete',
    'action' => 'Action',
    'node-add' => 'Add Node',

    'num' => 'Number',
    'prefix' => 'Prefix',

    'home-message' => 'Home Message',


    'users-total' => 'Total Users',
    'nodes-total' => 'Total Nodes',
    'traffic-total' => 'Total Traffic',

    'mailgun-key' => 'Mailgun Key',
    'mailgun-domain' => 'Mailgun Domain',
    'mailgun-sender' => 'Mailgun Sender',
];