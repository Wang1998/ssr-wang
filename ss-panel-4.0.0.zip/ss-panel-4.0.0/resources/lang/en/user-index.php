<?php

return [

    'announcement' => 'Announcement',
    'faq' => 'FAQ',

    'checkin' => 'Check-In',
    'checkin-des' => "You can checkin in each %s hour.",
    'cant-checkin' => "Cant't Check-In",
    'last-checkin-at' => 'Last check-in at',
    'traffic-got' => 'Your got ',

    'traffic-info' => 'Traffic Info',
    'traffic-total' => 'Total Traffic',
    'traffic-used' => 'Used Traffic',
    'traffic-unused' => 'Unused Traffic',

    'connection-info' => 'Connection Info',

    'last-used' => 'Last used at',

    'gen-invite-code' => 'Generate invitation code',
];
