export const Login = "Login";
export const ChangeLocale = "ChangeLocale";
export const StoreUser = "StoreUser";