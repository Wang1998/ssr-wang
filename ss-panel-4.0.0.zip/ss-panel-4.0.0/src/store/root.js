
export const state = {
    token: null,
    isLogin: false,
    id: 0,
    lang: 'en',
};