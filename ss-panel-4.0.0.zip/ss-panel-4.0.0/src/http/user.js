import axios from 'axios';

class User {
    constructor(id, token) {
        this.id = id;
        this.token = token;
    }

    nodes() {

    }

    info() {

    }
}

export default User